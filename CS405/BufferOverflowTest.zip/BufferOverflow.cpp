// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  //keeps while loop in control, if input is 20 or more, program will prompt the user to reinput data
  bool valid_input = false;
  //variable to temporarily store the raw_input from the user
  std::string raw_input;
  
  //While loop to ensure that user enters a valid input
  while (!valid_input) {
	  std::cout << "Enter a value: ";
	  std::cin >> raw_input;
	  //get size of the raw_input
	  int input_length = raw_input.size();
	  //If the input is less than the size of our input array, then we exit the loop
	  if (input_length < sizeof(user_input)) {
		  valid_input = true;
		  
	  }
	  else {
		  //forces user to reinput data
		  std::cout << "Invalid Input, Try again\n";
	  }
  }

  //converts raw_input string into the user_input array
  strncpy_s(user_input, raw_input.c_str(), sizeof(user_input));


  


  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

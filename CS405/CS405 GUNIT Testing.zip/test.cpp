// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
/*TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}*/

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0

    add_entries(1);
    ASSERT_EQ(collection->size(), 1);
    // is the collection still empty?
    // if not empty, what must the size be?
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    //store the size before adding entries
    int previous_size = collection->size();
    //Checks that the collection size +5 is less than the max size of the collection
    ASSERT_LT(collection->size() + 5, collection->max_size());
    add_entries(5);
    //after entries are added, the current size and the previous size + 5 should be equal
    ASSERT_EQ(previous_size + 5, collection->size());
    
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, EnsureMaxSizeGreaterThan10) 
{
    //test collection with size
    //expects the initial size to be 0
    EXPECT_EQ(collection->size(), 0);
    //tests if the max_size is greater than the current size
    ASSERT_GE(collection->max_size(), collection->size());
    //adds an entry
    add_entries(1);
    //expects the size to now be 1
    EXPECT_EQ(collection->size(), 1);
    //tests if the max size is greater than the current size
    ASSERT_GE(collection->max_size(), collection->size());
    add_entries(4);
    //current size should be 5
    EXPECT_EQ(collection->size(), 5);
    //is max size greater or equal to the current size
    ASSERT_GE(collection->max_size(), collection->size());
    add_entries(5);
    //current size should be 10
    EXPECT_EQ(collection->size(), 10);
    //is the max size greater or equal to 10
    ASSERT_GE(collection->max_size(), collection->size());
}
// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, EnsureCapacityGreaterThan10)
{

    //initial size should be 0
    EXPECT_EQ(collection->size(), 0);
    //is the capacity greater or equal to the current size
    ASSERT_GE(collection->capacity(), collection->size());
    add_entries(1);
    //current size should be 1
    EXPECT_EQ(collection->size(), 1);
    //is the capacity greater or equal to the current size
    ASSERT_GE(collection->capacity(), collection->size());
    add_entries(4);
    //current size should be 5
    EXPECT_EQ(collection->size(), 5);
    //is the capacity greater or equal to the current size
    ASSERT_GE(collection->capacity(), collection->size());
    add_entries(5);
    //current size should be 10
    EXPECT_EQ(collection->size(), 10);
    //is the capacity greater or equal to the current size
    ASSERT_GE(collection->capacity(), collection->size());
}
// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, EnsureResizeIncreasesCollection) 
{
    //collection size begins at 0
    EXPECT_EQ(collection->size(), 0);
    collection->resize(1);
    //collection size should increase to 1 after
    ASSERT_EQ(collection->size(), 1);

}
// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, EnsureResizeDecreasesCollection)
{
    add_entries(5);
    //collection size starts at 5
    EXPECT_EQ(collection->size(), 5);
    //resize to 3
    collection->resize(3);
    //collection should now have a size of 3
    ASSERT_EQ(collection->size(), 3);
}
// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, EnsureResizeIncreasesCollectionToZero)
{
    
    add_entries(1);
    //collection should have size of 1
    EXPECT_EQ(collection->size(), 1);
    //resize to 0
    collection->resize(0);
    //collection size should now be 0
    ASSERT_EQ(collection->size(), 0);
    
}
// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, EnsureClearErasesCollection)
{
    add_entries(5);
    //collection should have size of 5
    EXPECT_EQ(collection->size(), 5);
    collection->clear();
    //collection should be empty after clearing
    ASSERT_TRUE(collection->empty());
    

    //second test with different size collection to ensure clear doesn't just remove 5 elements
    //collection should have size of 7
    add_entries(7);
    EXPECT_EQ(collection->size(), 7);
    collection->clear();
    ASSERT_TRUE(collection->empty());

}
// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EnsureEraseErasesCollection)
{
    add_entries(5);
    //collection should have size of 5
    EXPECT_EQ(collection->size(), 5);
    collection->erase(collection->begin(), collection->end());
    //collection should be empty after erasing
    ASSERT_TRUE(collection->empty());


    //second test with different size collection to ensure erasing doesn't just remove 5 elements
    //collection should have size of 7
    add_entries(7);
    EXPECT_EQ(collection->size(), 7);
    collection->erase(collection->begin(), collection->end());
    ASSERT_TRUE(collection->empty());
}
// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, EnsureReserveIncreasesCapacityNotSize)
{
    //expect initial size to be 0
    EXPECT_EQ(collection->size(), 0);
    collection->reserve(10);
    ASSERT_EQ(collection->capacity(), 10);
    //makse sure collection size is still 0
    ASSERT_EQ(collection->size(), 0);
    //ensure that there is an actual increase
    collection->reserve(20);
    ASSERT_EQ(collection->capacity(), 20);
    //makse sure collection size is still 0
    ASSERT_EQ(collection->size(), 0);

}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, EnsureOutOfBountsException) 
{
    //expect initial size to be 0
    EXPECT_EQ(collection->size(), 0);
    int i;
    //try to assign i to a value out of range to cause the out of range error
    ASSERT_THROW(i = collection->at(0), std::out_of_range);
    
}


// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative

TEST_F(CollectionTest, EnsureLengthError)
{
    //this test tries to resize the collection to the max limit that a vector can be, this throws a length_error
    ASSERT_THROW(collection->resize(std::numeric_limits<size_t>::max()), std::length_error);
    

}

TEST_F(CollectionTest, EnsurePopBackReducesSize)
{
    //adds entries to begin
    add_entries(5);
    //excpects that the size is now 5
    EXPECT_EQ(collection->size(), 5);
    //removes one element
    collection->pop_back();
    //makes sure that the size is now 4
    ASSERT_EQ(collection->size(), 4);

}
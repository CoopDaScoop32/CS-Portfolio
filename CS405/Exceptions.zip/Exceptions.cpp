// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

class TooAdvancedException : public std::exception {
public:
    TooAdvancedException(const std::string& message) : message_(message) {}

    const char* what() const noexcept override {
        return message_.c_str();
    }
private:
    std::string message_;
};


bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    throw std::out_of_range("Too much data was allocated");

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        std::cout << "Exception caught: " << e.what() << std::endl;
    }
    

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    throw TooAdvancedException("Logic too advanced, try something simpler");

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0.0f) {
        throw std::runtime_error("Cannot Divide by Zero");
    }
    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.
    try {
        float numerator = 10.0f;
        float denominator = 0;

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (std::runtime_error& e) {
        std::cout << "Divide by Zero Error Caught: " << e.what() << std::endl;
    }
    
}

int main()
{
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        // TODO: Create exception handlers that catch (in this order):
        //  your custom exception
        //  std::exception
        //  uncaught exception 
        //  that wraps the whole main function, and displays a message to the console.

        do_division();
        do_custom_application_logic();
    }
    catch (TooAdvancedException& e) {
        std::cout << "TooAdvancedException Caught: " << e.what() << std::endl;
    }
    catch (std::exception& e) {
        std::cout << "Exception Caught: " << e.what() << std::endl;
    }
    catch (...) {
        std::cout << "Unknown Exception Caught" << std::endl;
    }
    
    
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu